<?php

namespace App\Controllers;

use App\Models\Usuario_model;

class Users extends BaseController {

    public function view($page = 'create') {
        //Si es diferente la existencia de un archivo se hace el retunamiento
        if (!is_file(APPPATH . 'Views/users/' . $page . '.php')) {
            // Encapsulamiento, optiene el error y muestro el erro
            throw new PageNotFoundException($page);
        }
        //El tittle nombre de la pagina y mantener un estandar 
        $data['title'] = ucfirst($page); // Capitalize the first letter
        //3 tipos de return que retorne 3 vistas diferentes
        return view('templates/header', $data)
                //el . concatena, parametro page, parametro la pagina , body
                . view('users/' . $page)
                //pie de pagina
                . view('templates/footer');
    }

    public function create() {
        helper('form');

        if (!$this->request->is('post')) {
            return view('templates/header', ['title' => 'Create a user'])
                    . view('/users/create')
                    . view('templates/footer');
        }

        $post = $this->request->getPost(['nombre', 'documento', 'telefono', 'direccion']);

        if (!$this->validateData($post, [
                    'nombre' => 'required|min_length[3]|max_length[255]',
                    'documento' => 'required|min_length[7]|max_length[255]',
                    'telefono' => 'required|min_length[2]',
                    'direccion' => 'required|min_length[2]',
                ])) {
            return view('templates/header', ['title' => 'Create a user'])
                    . view('../users/login')
                    . view('templates/footer');
        }

        $model = model(Usuario_model::class);

        $model->save([
            'nombre' => $post['nombre'],
            'documento' => $post['documento'],
            'telefono' => $post['telefono'],
            'direccion' => $post['direccion'],
        ]);

        return view('templates/header', ['title' => 'Create a user'])
                . view('/users/login')
                . view('templates/footer');
    }

    public function update() {
        helper('form');

        if (!$this->request->is('post')) {
            return view('templates/header', ['title' => 'Update a user'])
                    . view('/users/update')
                    . view('templates/footer');
        }

        $post = $this->request->getPost(['nombre', 'documento', 'telefono', 'direccion']);

        if (!$this->validateData($post, [
                    'nombre' => 'required|min_length[3]|max_length[255]',
                    'documento' => 'required|min_length[7]|max_length[255]',
                    'telefono' => 'required|min_length[2]',
                    'direccion' => 'required|min_length[2]',
                ])) {
            return view('templates/header', ['title' => 'Update a user'])
                    . view('../users/login')
                    . view('templates/footer');
        }

        $model = model(Usuario_model::class);

        $documento = $post['documento'];

        $model->where('documento', $documento)->set([
            'nombre' => $post['nombre'],
            'documento' => $post['documento'],
            'telefono' => $post['telefono'],
            'direccion' => $post['direccion'],
        ])->update();

        return view('templates/header', ['title' => 'Update a user'])
                . view('/users/login')
                . view('templates/footer');
    }

}
